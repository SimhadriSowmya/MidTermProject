﻿using System;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
namespace Tracker
{
    class Tracking
    {
        static void Main(string[] args)
        {
            Api api = new Api("Your Api Key");

            // Get realtime tracking results of a single tracking
            string post = "[{\"tracking_number\": \"YT2205421266056615\", \"courier_code\": \"yunexpress\"},{\"tracking_number\": \"303662548678\", \"courier_code\": \"qichen\"}]";

            // create  tracking number
            response = api.doRequest("create", post, "POST");
            Console.WriteLine(response.Content.ReadAsStringAsync().Result);

            // Get tracking results of a  tracking or List all trackings
            // string get = "get?tracking_numbers=YT2205421266056615,303662548678";
            // response = api.doRequest(get);
            // Console.WriteLine(response.Content.ReadAsStringAsync().Result);

            // count
            // string count = "count?created_date_min=1646064000&created_date_max=1648742400";
            // response = api.doRequest(count);
            // Console.WriteLine(response.Content.ReadAsStringAsync().Result);

            // // Update Tracking item
            // response = api.doRequest("modifyinfo", post, "PUT");
            // Console.WriteLine(response.Content.ReadAsStringAsync().Result);

            // // Delete tracking item
            // response = api.doRequest("delete", post, "DELETE");
            // Console.WriteLine(response.Content.ReadAsStringAsync().Result);
        }
    }
}
