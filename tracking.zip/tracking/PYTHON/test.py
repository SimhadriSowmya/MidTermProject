#!/usr/bin/python
# -*- coding: UTF-8 -*-
import json
import trackApi

if __name__ == '__main__':
    apiKey = "your api key"
    tracker = trackApi.TrackingApi(apiKey)
    tracker.sandbox = True
    post = [
        {"tracking_number": "YT2205421266056615", "courier_code": "yunexpress"},
        {"tracking_number": "303662548678", "courier_code": "qichen"}
    ]
    postData = json.dumps(post)

    # create tracking number
    result = tracker.doRequest("create", postData, "POST")
    print(json.loads(result.decode('utf-8')))

    # # Get tracking results of a  tracking or List all trackings
    # get = "get?tracking_numbers=YT2205421266056615,303662548678"
    # result = tracker.doRequest(get)
    # print(json.loads(result.decode('utf-8')))

    # # get all carriers
    # result = tracker.doRequest("carriers")
    # print(json.loads(result.decode('utf-8')))

    # count
    # count = "count?created_date_min=1646064000&created_date_max=1648742400"
    # result = tracker.doRequest(count)
    # print(json.loads(result.decode('utf-8')))

    # # Update Tracking item
    # result = tracker.doRequest("modifyinfo", postData, "PUT")
    # print(json.loads(result.decode('utf-8')))

    # # Delete tracking item
    # result = tracker.doRequest("delete", postData, "DELETE")
    # print(json.loads(result.decode('utf-8')))