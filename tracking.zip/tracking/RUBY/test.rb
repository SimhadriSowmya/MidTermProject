#!/usr/bin/ruby -w
# frozen_string_literal: true
require "#{File.dirname(__FILE__)}/tracking.rb"
api_key = 'Your api key'
tracker = Tracking.new(api_key)

post = [
	{"tracking_number": "YT2205421266056615", "courier_code": "yunexpress"},
	{"tracking_number": "303662548678", "courier_code": "qichen"}
]

# # create  tracking number
result = tracker.doRequest('create', post, 'POST')
print("#{result}\n")
#
# # Get tracking results of a  tracking or List all trackings
# get = 'get?tracking_numbers=YT2205421266056615,303662548678'
# result = tracker.doRequest(get)
# print("#{result}\n")
#
# # get all carriers
# result = tracker.doRequest('courier')
# print("#{result}\n")
#
# #count
# count = 'count?created_date_min=1646064000&created_date_max=1648742400'
# result = tracker.doRequest(count)
# print("#{result}\n")
#
# # Update Tracking item
# result = tracker.doRequest('modifycourier', post, 'PUT')
# print("#{result}\n")
#
# # Delete tracking item
# result = tracker.doRequest('delete', post, 'DELETE')
# print("#{result}\n")
#