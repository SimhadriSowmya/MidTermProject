import api.Api;

public class Test {

    static Api api = new Api("Your-api-key");

    public static void main(String[] args) {
        //api.sandbox = true;
        // create tracking number
        String res = api.create("[{\"tracking_number\":\"YT2205421266056615\",\"courier_code\":\"yunexpress\"},{\"tracking_number\": \"303662548678\", \"courier_code\": \"qichen\"}]");
        System.out.println(res);
        // get tracking number
        // String res = api.get("tracking_numbers=UB209300714LV");
        // System.out.println(res);
    }
}
