package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"time"
)

func doRequest(endpoint string, data interface{}, method string) (content string) {
	var jsonStr []byte
	if data != nil {
		jsonStr, _ = json.Marshal(data)
	}
	method = strings.ToUpper(method)
	requestUrl := "https://api.trackingmore.com/v3/trackings/" + endpoint
	req, err := http.NewRequest(method, requestUrl, bytes.NewBuffer(jsonStr))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Tracking-Api-Key", "Your_Api_Key")
	if err != nil {
		panic(err)
	}
	defer req.Body.Close()

	client := &http.Client{Timeout: 20 * time.Second}
	resp, err2 := client.Do(req)
	if err2 != nil {
		panic(err2)
	}
	defer resp.Body.Close()

	result, _ := ioutil.ReadAll(resp.Body)
	content = string(result)
	return content
}

func main() {
	var res string
	var endpoint string
	type Item struct {
		TrackingNumber string `json:"tracking_number"`
		CourierCode    string `json:"courier_code"`
		OrderNumber    string `json:"order_number"`
	}
	// create a tracking number
	endpoint = "create"
	res = doRequest(endpoint, []Item{
		{
			TrackingNumber: "YT2205421266056615",
			CourierCode:    "yunexpress",
		},
		{
			TrackingNumber: "303662548678",
			CourierCode:    "qichen",
		},
	}, "POST")
	fmt.Println(res)

	//Get tracking results of a  tracking or List all trackings
	// endpoint = "get?tracking_numbers=YT2205421266056615,303662548678"
	// res = doRequest(endpoint, nil, "GET")
	// fmt.Println(res)

	// get all carriers
	// endpoint = "courier"
	// res = doRequest(endpoint, nil, "GET")
	// fmt.Println(res)

	//count
	// endpoint = "count?created_date_min=1646064000&created_date_max=1648742400"
	// res = doRequest(endpoint, nil, "GET")
	// fmt.Println(res)

	//Update Tracking item
	// endpoint = "modifyinfo"
	// res = doRequest(endpoint, []Item{
	// 	{
	// 		TrackingNumber: "YT2205421266056615",
	// 		CourierCode:    "yunexpress",
	// 		OrderNumber:    "123456",
	// 	},
	// }, "PUT")
	// fmt.Println(res)

	//Delete tracking item
	// endpoint = "delete"
	// res = doRequest(endpoint, []Item{
	// 	{
	// 		TrackingNumber: "UB209300714LV",
	// 		CourierCode:    "cainiao",
	// 	},
	// }, "DELETE")
	// fmt.Println(res)
}
